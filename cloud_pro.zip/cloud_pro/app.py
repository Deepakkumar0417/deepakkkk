from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import pandas as pd
import joblib
import logging
import mysql.connector

# Initialize the app
app = Flask(__name__)
CORS(app)

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Database configuration
db_config = {
    'host': 'database-1.ctw8ogusg6d0.ap-south-1.rds.amazonaws.com',
    'user': 'admin',
    'password': '12345678',
    'database': 'Loan'
}

# Load the trained model
model = joblib.load('rf_model_with_smote.pkl')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json
        app.logger.debug(f"Received data: {data}")

        input_data = pd.DataFrame([data])
        app.logger.debug(f"Input DataFrame: {input_data}")

        # Make prediction
        prediction = model.predict(input_data)
        result = "Loan Not Approved" if prediction == 1 else "Loan Approved"

        # Save to the database
        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()

        insert_query = """
        INSERT INTO LoanData (
            LIMIT_BAL, SEX, EDUCATION, MARRIAGE, AGE, 
            PAY_0, PAY_2, PAY_3, PAY_4, PAY_5, PAY_6, 
            BILL_AMT1, BILL_AMT2, BILL_AMT3, BILL_AMT4, BILL_AMT5, BILL_AMT6, 
            PAY_AMT1, PAY_AMT2, PAY_AMT3, PAY_AMT4, PAY_AMT5, PAY_AMT6, 
            prediction
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        values = (
            data['LIMIT_BAL'], data['SEX'], data['EDUCATION'], data['MARRIAGE'], data['AGE'], 
            data['PAY_0'], data['PAY_2'], data['PAY_3'], data['PAY_4'], data['PAY_5'], data['PAY_6'], 
            data['BILL_AMT1'], data['BILL_AMT2'], data['BILL_AMT3'], data['BILL_AMT4'], data['BILL_AMT5'], data['BILL_AMT6'], 
            data['PAY_AMT1'], data['PAY_AMT2'], data['PAY_AMT3'], data['PAY_AMT4'], data['PAY_AMT5'], data['PAY_AMT6'], 
            result
        )
        cursor.execute(insert_query, values)
        connection.commit()

        cursor.close()
        connection.close()

        return jsonify({'prediction': result})
    except Exception as e:
        app.logger.error(f"Error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/')
def home():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
